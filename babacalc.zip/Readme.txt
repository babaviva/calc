BABACALC

Babacalc provides a 'frontend' to the javascript calculator library decimal.js 
created by Michael Mclaughlin <M8ch88l@gmail.com>

Babacalc is a user friendly calculator that converts the inputs from the user into 
the javascript inputs that decimal.js requires and then formats the result for display.

babacalc.html is a portrait layout calculator
babaouter.html loads babacalc.html in a frame and optimizes it for common mobile devices.
babacalcl.html is an alternative landscape layout of the calculator.
 
The link between Babacalc and decimal.js has been extensively tested but if you find 
any example where it fails (Comparing results with a standard calculator) 
please notify me.

Chris Tomlinson <chris@babaviva.net>



